package com.mycustomgun.TestRunner.api;


import java.io.File;

import org.json.simple.JSONObject;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mycustomgun.TestBase.APITestBase;
import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TC1_API_Login extends APITestBase {
	
	public static RequestSpecification httpRequest;
	public static Response response;

	@BeforeClass
	public void launchApp() {
		getDatas(this.getClass().getSimpleName());
	}

	@SuppressWarnings("unchecked")
	@Test(priority = 1, description = "This test case will validate login")
	public void customer_Registraion() throws InterruptedException {
		try {
			test = report.startTest(getData("Description"));
			test.log(LogStatus.INFO, "Test Started" + test.getStartedTime());
				
			RestAssured.baseURI = prop.getProperty("apibase_url");
			httpRequest = RestAssured.given();
			
			JSONObject requestParams = new JSONObject();
			requestParams.put("firearm_platform_name", "AR15"); // Cast
			requestParams.put("orientation", "Right");
			requestParams.put("firearm_type", "Rifle");
			requestParams.put("caliber", "556 NATO");
			requestParams.put("GunTypecontentHeading",null);
			
			File jsonDataInFile = new File("./src/main/resources/com/mycustomgun/requestbody/test.json");
			 ObjectMapper mapper = new ObjectMapper();
			
			JSONObject root = mapper.readValue(jsonDataInFile, JSONObject.class);

			test.log(LogStatus.PASS, "Request body"+root);
			
			httpRequest.header("Content-Type", "application/json");
			httpRequest.header("auth._token.localRefresh", "Bearer"+getAccessToken(getData("LoginUserName"),getData("LoginPassword")));
			httpRequest.body(root);
		
			response = httpRequest.request(Method.POST, "/api/custombuilt/getAllPartsForPlatformCombination");
		
			if(response.getStatusCode()==200) {
				test.log(LogStatus.PASS, "Result"+response.getBody().asString());
			}else {
				test.log(LogStatus.FAIL, "Result"+response.getBody().asString());
			}
			
		} catch (Exception ex) {
			
			test.log(LogStatus.FAIL, "Result" + ex.getMessage());
		}
	}

	@AfterClass
	public void endApp() {
		
	}

}
