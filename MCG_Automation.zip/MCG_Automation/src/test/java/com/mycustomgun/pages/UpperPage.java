package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.testng.Assert;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class UpperPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils comutils = new CommonUtils();

	public UpperPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-3.tab-pane div.st-dropdown-area"))
	public List<WebElement> upperattributes;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.bot_disclamier div.st-builder-gun-price1")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void upperPageSelection() {
		selectStrippedUpper();
		selectBarrel();
		selectGasTube();
		selectGasBlock();
		selectBoltCarrierGroup();
		selectCharging_Handle();
		selectForwardAssist();
		selectEjectionCover();
		seleutils.javascriptClick(nextbtn, driver, "Upper Page Next Button");
	}

	public void selectStrippedUpper() {
		seleutils.javascriptClick(upperattributes.get(0).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Stripped Upper dropdown");
		List<WebElement> platformlist = upperattributes.get(0).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Stripped_Upper"))) {
			seleutils.javascriptClick(ele, driver, "Select the Stripped Upper");
			seleutils.priceChecker(getData("Stripped_Upper_Price"),ele,driver);
			seleutils.speficationValidation("Stripped Upper",getData("Stripped_Upper_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectBarrel() {
		seleutils.javascriptClick(upperattributes.get(1).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Barrel dropdown");
		List<WebElement> listsofitems = upperattributes.get(1).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Barrel"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Barrel");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Barrel_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Barrel");
			seleutils.speficationValidation("Barrel",getData("Barrel_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
		}

	public void selectGasBlock() {
		seleutils.javascriptClick(upperattributes.get(2).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Gas Block dropdown");
		List<WebElement> listsofitems = upperattributes.get(2).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Gas_Block"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Gas Block");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Gas_Block_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Gas Block");
			seleutils.speficationValidation("Gas Block",getData("Gas_Block_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectGasTube() {
		seleutils.javascriptClick(upperattributes.get(3).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Gas Tube dropdown");
		List<WebElement> listsofitems = upperattributes.get(3).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Gas_Tube"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Gas Tube");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Gas_Tube_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Gas Block");
			seleutils.speficationValidation("Gas Tube",getData("Gas_Tube_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	public void selectBoltCarrierGroup() {
		seleutils.javascriptClick(upperattributes.get(4).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Bolt Carrier Group dropdown");
		List<WebElement> listsofitems = upperattributes.get(4).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Bolt_Carrier_Group"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Bolt Carrier Group");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Bolt_Carrier_Group_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Gas Block");
			seleutils.speficationValidation("Bolt Carrier Group",getData("Bolt_Carrier_Group_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	public void selectCharging_Handle() {
		seleutils.javascriptClick(upperattributes.get(5).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Charging Handle dropdown");
		List<WebElement> listsofitems = upperattributes.get(5).findElements(By.cssSelector("div:nth-child(3) div.st-radio-area label"));
		System.out.println(listsofitems);
		for(WebElement ele: listsofitems) {
			WebElement labelitem = ele.findElement(By.cssSelector("input"));
			if(seleutils.javascriptgetTextbyval(labelitem,driver).contains(getData("Charging_Handle"))) {
			seleutils.javascriptClick(labelitem, driver, "Select the Charging Handle");
			WebElement price = ele.findElement(By.cssSelector("span"));
			seleutils.priceChecker(getData("Charging_Handle_Price"),price,driver);
			WebElement addbtn = ele.findElement(By.cssSelector("button"));
			seleutils.javascriptClick(addbtn, driver, "Add the Charging Handle");
			seleutils.speficationValidation("Charging Handle",getData("Charging_Handle_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectForwardAssist() {
		seleutils.javascriptClick(upperattributes.get(6).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Forward Assist");
		List<WebElement> platformlist = upperattributes.get(6).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Forward_Assist"))) {
			seleutils.javascriptClick(ele, driver, "Select the Forward Assist");
			seleutils.priceChecker(getData("Forward_Assist_Price"),ele,driver);
			seleutils.speficationValidation("Forward Assist",getData("Forward_Assist_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}
	
	public void selectEjectionCover() {
		seleutils.javascriptClick(upperattributes.get(7).findElement(By.cssSelector("div:nth-child(2)")), driver, "Click on Ejection Cover");
		List<WebElement> platformlist = upperattributes.get(7).findElements(By.cssSelector("div:nth-child(3) button"));
		for(WebElement ele: platformlist) {
			if(seleutils.javascriptgetTextbyval(ele,driver).contains(getData("Ejection_Cover"))) {
			seleutils.javascriptClick(ele, driver, "Select the Ejection Cover");
			seleutils.priceChecker(getData("Ejection_Cover_Price"),ele,driver);
			seleutils.speficationValidation("Ejection Cover",getData("Ejection_Cover_Price"),selecteditemname,selecteditemprice,driver);
			seleutils.validateprice(gunprice,ele,driver);
			break;
			}
		}
	}

}
