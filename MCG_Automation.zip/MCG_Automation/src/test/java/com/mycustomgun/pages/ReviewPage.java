package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class ReviewPage extends TestBase {
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils utils = new CommonUtils();

	public ReviewPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "form.v-form input")) // 1,2,3,4
	public List<WebElement> cards;
	@FindBy(css = "div.center button")
	public WebElement placeyourorder;
	@FindBys(@FindBy(css = "div.rightcontent tr td")) // 1,2,3,4
	public List<WebElement> orederitems;
	@FindBys(@FindBy(css = "div.subcontent div.sub1 p.subdetails span")) // 1-7
	public List<WebElement> billingdetails;
	@FindBys(@FindBy(css = "div.subcontent div.sub2 p.subdetails span")) // 1-5
	public List<WebElement> shippingdetails;
	@FindBys(@FindBy(css = "div.subcontent div.sub3 span")) // 1-6
	public List<WebElement> flldetails;
	@FindBy(css = "div.subcontent div.sub1 i")
	public WebElement editbilling;
	@FindBy(css = "div.subcontent div.sub2 i")
	public WebElement editshipping;
	@FindBys(@FindBy(css = "div.v-date-picker-header button"))
	public List<WebElement> years;
	@FindBys(@FindBy(css = "div.v-date-picker-table tr td div"))
	public List<WebElement> months;
	@FindBy(css = "div.rightcontent span.order1")
	public WebElement totalprice;

	public void reviewselection() {
		cardfill();
		verifytotal();
		seleutils.javascriptClick(placeyourorder, driver, "Click on Placed Order");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void cardfill() {
		seleutils.javascriptClick(cards.get(0), driver, "Click on Card Name");
		seleutils.javascriptClearText(cards.get(0), driver);
		seleutils.seleSendKeys(cards.get(0), getData("CardName"), "Enter Card Name", driver);
		seleutils.javascriptClick(cards.get(1), driver, "Click on CardNumber");
		seleutils.seleSendKeys(cards.get(1), getData("CardNumber"), "Enter Card Number", driver);
		expiredate();
		// seleutils.JsSendKeys(cards.get(2), getData("ExpireMonth"), "Enter Expire
		// Date",driver);
		seleutils.javascriptClick(cards.get(3), driver, "Click on CVV");
		seleutils.seleSendKeys(cards.get(3), getData("CVVNumber"), "Enter CVV Number", driver);
	}

	public void expiredate() {
		seleutils.javascriptClick(cards.get(2), driver, "Click on Expire Date");
		String[] dates = utils.expiredate(getData("ExpireMonth"));
		int givenmonthnum = Integer.parseInt(dates[0]);
		int givenyear = Integer.parseInt(dates[1]);
		String month = givenmonth(givenmonthnum);
		selectyear(givenyear);
		selectmonth(month);
	}

	public void verifytotal() {
		String price = utils.TotalpriceValidation1(seleutils.javascriptgetTextbyInnerHtml(totalprice, driver).trim());
		seleutils.asserstEqualsvalues(price, getData("Current_Price"));
	}

	public void selectmonth(String givenmonth) {
		for (WebElement month : months) {
			if (seleutils.javascriptgetTextbyInnerHtml(month, driver).trim().equalsIgnoreCase(givenmonth)) {
				seleutils.javascriptClick(month, driver, "Click on month");
				break;
			}
		}
	}

	public void selectyear(int givenyear) {
		boolean notselectyear = true;
		while (notselectyear) {
			String currentyear = seleutils.javascriptgetTextbyInnerHtml(years.get(1), driver);
			int currentyearnum = Integer.parseInt(currentyear);
			if (currentyearnum == givenyear) {
				notselectyear = false;
			} else if (currentyearnum < givenyear) {
				seleutils.javascriptClick(years.get(2), driver, "Click because year is low");
			} else {
				seleutils.javascriptClick(years.get(0), driver, "Click because year is higher");
			}
		}
	}

	public String givenmonth(int givenmonthnum) {
		String givenmonth = null;
		switch (givenmonthnum) {
		case 1:
			givenmonth = "Jan";
			break;
		case 2:
			givenmonth = "Feb";
			break;
		case 3:
			givenmonth = "Mar";
			break;
		case 4:
			givenmonth = "Apr";
			break;
		case 5:
			givenmonth = "May";
			break;
		case 6:
			givenmonth = "Jun";
			break;
		case 7:
			givenmonth = "Jul";
			break;
		case 8:
			givenmonth = "Aug";
			break;
		case 9:
			givenmonth = "Sep";
			break;
		case 10:
			givenmonth = "Oct";
			break;
		case 11:
			givenmonth = "Nov";
			break;
		case 12:
			givenmonth = "Dev";
			break;
		default:
			System.out.println("Wrong Month");
		}
		return givenmonth;

	}

}
