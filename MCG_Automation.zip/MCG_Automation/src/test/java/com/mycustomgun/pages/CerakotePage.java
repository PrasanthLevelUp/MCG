package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class CerakotePage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public CerakotePage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.v-stepper__header div:nth-child(2)"))
	public List<WebElement> headers;
	@FindBys(@FindBy(css = "div#step-8 div.st-dropdown-btn")) 
	public WebElement selectcerakoteattribute;  
	@FindBys(@FindBy(css = "div.st-dropdown-area div.st-dropdown-content div.alignment p"))
	public List<WebElement> selectcolourbtn;
	@FindBy(css = "div.step-btns button:nth-child(1)")
	public WebElement backbtn;
	@FindBy(css = "button#nextBtn")
	public WebElement nextbtn;
	@FindBy(css = "div.st-builder-gun-price")
	public WebElement gunprice;
	@FindBy(css = "table.item td")
	public WebElement selecteditemname;
	@FindBy(css = "table.price td")
	public WebElement selecteditemprice;
	@FindBy(css = "div.specifications div.description span:nth-child(2)")
	public WebElement selecteditemdescription;
	
	public void cerakotePageSelection() {

		CerakoteSelection();
		seleutils.javascriptClick(nextbtn, driver, "cerakote Page Next");
	}

	public void CerakoteSelection() {
		seleutils.javascriptClick(selectcerakoteattribute, driver, "Click on Cerakote Color dropdown");
		for (WebElement ele : selectcolourbtn) {
			if (seleutils.javascriptgetTextbyInnerHtml(ele, driver).contains(getData("Cerakote"))) {
				seleutils.javascriptClick(ele, driver, "Select the Cerakote Color");
				seleutils.speficationValidation("Cerakote", getData("Cerakote_Price"), selecteditemname,
						selecteditemprice, driver);
				seleutils.validatepriceColor(gunprice, selecteditemprice, driver);
				break;
			}
		}
	}
}
