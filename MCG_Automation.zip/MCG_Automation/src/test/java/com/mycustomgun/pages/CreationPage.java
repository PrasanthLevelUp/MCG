package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class CreationPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils utils = new CommonUtils();

	public CreationPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.all div.d-flex.c-content button:nth-child(2)") //if single item
	public WebElement addtocardbtn;
	@FindBy(css = "div.all div.d-flex.c-content button:nth-child(1)") //if single item
	public WebElement deletebtn;
	@FindBy(css = "div.all div.d-flex.c-content")
	public WebElement createditem;
	@FindBys(@FindBy(css = "div.all div.d-flex"))
	public List<WebElement> listofguns;
	@FindBy(css = "a[href='/cart']")
	public WebElement checkoutbtn;
	@FindBy(css = "div.all div.d-flex div#cartname")
	public WebElement itemname;
	@FindBy(css = "div.all div.d-flex div#cartprice")
	public WebElement itemprice;
	
	public void creategunseletion() {
		verifygunname();
		verifygunprice();
		addtocart();
		seleutils.javascriptClick(checkoutbtn, driver, "Click on go to cart");
	}
	
	public void addtocart() {
		List<WebElement> buttons = listofguns.get(1).findElements(By.cssSelector("button"));
		seleutils.javascriptClick(buttons.get(1), driver, "Click on Add to cart");
	}
	
	public void verifygunname() {
		
		seleutils.asserstEqualsvalues(seleutils.javascriptgetTextbyInnerHtml(itemname, driver).trim(),getData("GunName"));
	}
	
	public void verifygunprice() {
		String price = utils.TotalpriceValidation1(seleutils.javascriptgetTextbyInnerHtml(itemprice, driver).trim());
		seleutils.asserstEqualsvalues(price,getData("Current_Price"));
	}
	
}
