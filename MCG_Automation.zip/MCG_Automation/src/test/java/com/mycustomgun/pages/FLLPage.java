package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class FLLPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public FLLPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.z-code input")
	public WebElement zipcode;
	@FindBy(css = "div.s-radius div.selectBox")
	public WebElement radius;
	@FindBys(@FindBy(css = "div.s-radius div.selectBoxOption")) //1-8
	public List<WebElement> radiusOption;
	@FindBy(css = "div.find-dealer")
	public WebElement finddealerbtn;
	@FindBys(@FindBy(css = "div.choose-d div.c-dealer")) //1-8
	public List<WebElement> dealerresults;
	@FindBy(css = "div.ffl-dealer div.dname")
	public WebElement delarnname;
	@FindBy(css = "div.ffl-dealer div.use-dealer span")
	public WebElement selectdelar;


	public void fllselection() {
		seleutils.javascriptClick(finddealerbtn, driver, "Click on find dealer");
		for(WebElement dealer : dealerresults) {
			if(seleutils.javascriptgetTextbyInnerHtml(dealer, driver).trim().equalsIgnoreCase(getData("FllDDealer"))) {
				System.out.println("2");
				seleutils.javascriptClick(dealer, driver, "Select on dealer");
				break;
			}
		}
		seleutils.javascriptClick(selectdelar, driver, "Click on select dealer");
	}

}
