package com.mycustomgun.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class CheckoutPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils utils = new CommonUtils();

	public CheckoutPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.center button"))
	public List<WebElement> Loginbuttons; 
	@FindBy(css = "form.v-form input[autocomplete='username']")
	public WebElement emailid;
	@FindBy(css = "form.v-form input[autocomplete='current-password']")
	public WebElement password;
	@FindBy(css = "div.v-input__append-inner button")
	public WebElement hiddenicon;
	@FindBys(@FindBy(css = "form.v-form div.v-text-field__slot input")) //1 and 2
	public List<WebElement> gunnameanddesc;
	@FindBy(css = "div.gun-name button")
	public WebElement button;
	
	public void checkselection() {
		fillgunnames();
		checkout();
	}

	public void checkout() {
		seleutils.javascriptClick(button, driver, "Click on checkout button");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void fillgunnames() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		seleutils.javascriptClick(gunnameanddesc.get(0), driver, "Click on Gun Name");
		seleutils.seleSendKeys(gunnameanddesc.get(0), gunname(), "Enter Gun Name",driver);
		seleutils.javascriptClick(gunnameanddesc.get(1), driver, "Click on Gun Description");
		seleutils.seleSendKeys(gunnameanddesc.get(1), getData("GunDesc"), "Enter Gun Description",driver);
	}
	
	public String gunname() {
		String name = utils.generateName();
		try {
			setData("GunName",name);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return name;
	}

	public void skipguestuser() {
		seleutils.javascriptClick(Loginbuttons.get(1), driver, "Click on Skip and Guest User");	
	}
	
	public void loginuser() {
		seleutils.javascriptClick(emailid, driver, "Click to login");
		seleutils.seleSendKeys(emailid, getData("LoginUserName"), "Enter Email",driver);
		emailid.sendKeys(Keys.TAB);
		seleutils.seleSendKeys(password, getData("LoginPassword"), "Enter Password",driver);
		password.sendKeys(Keys.TAB);
		hiddenicon.sendKeys(Keys.TAB);
		//login.sendKeys(Keys.ENTER);
		seleutils.javascriptClick(Loginbuttons.get(0), driver, "Click on Login");	
	}

}
