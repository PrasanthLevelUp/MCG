package com.mycustomgun.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.SeleniumUtils;

public class ShippingPage extends TestBase{
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();

	public ShippingPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBys(@FindBy(css = "div.ship-content div.dflex div.flexgrow div.v-text-field__slot input")) //1,2
	public List<WebElement> shipdetails;
	@FindBys(@FindBy(css = "div.align input")) //1,2
	public List<WebElement> shipaddress;
	@FindBys(@FindBy(css = "div.dflex div.v-text-field__slot input")) //1,2,3
	public List<WebElement> cityzip;
	@FindBy(css = "div.v-select__selections")
	public WebElement state;
	@FindBys(@FindBy(css = "div.v-select-list div.v-list-item__title"))
	public List<WebElement> statelist;
	@FindBys(@FindBy(css = "div.contact-info div.flexgrow input"))
	public List<WebElement> contactinfo;
	@FindBy(css = "input#check")
	public WebElement checkbox;
	@FindBy(css = "div.contact-info div.btn button")
	public WebElement conituebtn;
	
	
	public void fillshippingdetails() {
		seleutils.javascriptClick(shipdetails.get(0), driver, "Click on First name");
		seleutils.javascriptClearText(shipdetails.get(0), driver);
		seleutils.seleSendKeys(shipdetails.get(0), getData("BillingFN"), "Enter First Name",driver);
		seleutils.javascriptClick(shipdetails.get(1), driver, "Click on Last name");
		seleutils.seleSendKeys(shipdetails.get(1), getData("BillingLN"), "Enter Last Name",driver);
		seleutils.javascriptClick(shipaddress.get(0), driver, "Click on Address Line 1 ");
		seleutils.seleSendKeys(shipaddress.get(0), getData("BillingLN"), "Enter Address Line 1",driver);
		seleutils.javascriptClick(cityzip.get(2), driver, "Click on City ");
		seleutils.seleSendKeys(cityzip.get(2), getData("City"), "Enter the City",driver);
		seleutils.javascriptClick(state, driver, "Click on State");
		for(WebElement state : statelist) {
			if(seleutils.javascriptgetTextbyInnerHtml(state, driver).equalsIgnoreCase(getData("State"))) {
				seleutils.javascriptClick(state, driver, "Select on State");
				break;
			}
		}
		seleutils.javascriptClick(cityzip.get(3), driver, "Click Zipcode");
		seleutils.seleSendKeys(cityzip.get(3), getData("Zipcode"), "Enter Zipcode",driver);
		seleutils.javascriptClick(cityzip.get(4), driver, "Click on Email");
		seleutils.javascriptClearText(cityzip.get(4), driver);
		seleutils.seleSendKeys(cityzip.get(4), getData("ShippingEmail"), "Enter Email",driver);
		seleutils.javascriptClick(cityzip.get(5), driver, "Click on  Mobile");
		seleutils.seleSendKeys(cityzip.get(5), getData("ShippingMoible"), "Enter Mobile",driver);
	//	seleutils.javascriptClick(checkbox, driver, "Click on  Checkbox");
		seleutils.javascriptClick(conituebtn, driver, "Click on  Continue");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
