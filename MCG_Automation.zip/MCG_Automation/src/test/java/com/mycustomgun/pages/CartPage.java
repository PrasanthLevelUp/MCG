package com.mycustomgun.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.mycustomgun.TestBase.TestBase;
import com.mycustomgun.Utils.CommonUtils;
import com.mycustomgun.Utils.SeleniumUtils;

public class CartPage extends TestBase {
	WebDriver driver;

	SeleniumUtils seleutils = new SeleniumUtils();
	CommonUtils utils = new CommonUtils();

	public CartPage(WebDriver ldriver) {
		this.driver = ldriver;
	}

	@FindBy(css = "div.cart-item-desc p") // if single item
	public WebElement guncontent;
	@FindBy(css = "div.cart-item-price strong") // if single item
	public WebElement gunprice;
	@FindBy(css = "div.cart-total-price strong") // if single item
	public WebElement totalprice;
	@FindBy(css = "div.proceed-checkout button")
	public WebElement checkoutbtn;

	public void checkout() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		verifygunname();
		verifygunprice();
		verifytotalgunprice();
		seleutils.javascriptClick(checkoutbtn, driver, "Click on go to cart");
	}

	public void verifygunname() {
		String Actualname = seleutils.javascriptgetTextbyInnerHtml(guncontent, driver).trim();
		String[] name = Actualname.split(" ") ;
		seleutils.asserstEqualsvalues(name[0],getData("GunName"));
	}

	public void verifygunprice() {
		String price = utils.TotalpriceValidation1(seleutils.javascriptgetTextbyInnerHtml(gunprice, driver).trim());
		seleutils.asserstEqualsvalues(price, getData("Current_Price"));
	}
	
	public void verifytotalgunprice() {
		String price = utils.TotalpriceValidation1(seleutils.javascriptgetTextbyInnerHtml(totalprice, driver).trim());
		seleutils.asserstEqualsvalues(price, getData("Current_Price"));
	}
}
